
$(document).ready(function () {
  $(toolbar('shout_text')).insertBefore('#shout_text');
  buttons('shout_text');
  $('#yuieditor-emoticons_shout_text').popupMenu(false);

  function buttons(qse_area) {
    return
  }
});
